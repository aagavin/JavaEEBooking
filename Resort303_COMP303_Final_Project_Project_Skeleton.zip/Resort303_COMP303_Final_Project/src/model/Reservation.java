package model;
import java.io.Serializable;
import javax.persistence.*;
@Entity
@NamedQuery(name="Reservation.findAll", query="SELECT r FROM Reservation r")
public class Reservation implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String cardname;
	private String cc;
	private String cvv2;
	private int endDate;
	private String exp;
	private byte miniBar;
	private int roomId;
	private byte roomService;
	private int startDate;
	@ManyToOne
	@JoinColumn(name="userId")
	private Customer customer;
	public Reservation() { }
	public int getId() { return this.id; }
	public void setId(int id) {	this.id = id; }
	public String getCardname() { return this.cardname; }
	public void setCardname(String cardname) { this.cardname = cardname; }
	public String getCc() { return this.cc; }
	public void setCc(String cc) { this.cc = cc; }
	public String getCvv2() { return this.cvv2; }
	public void setCvv2(String cvv2) { this.cvv2 = cvv2; }
	public int getEndDate() { return this.endDate; }
	public void setEndDate(int endDate) { this.endDate = endDate; }
	public String getExp() { return this.exp; }
	public void setExp(String exp) { this.exp = exp; }
	public byte getMiniBar() { return this.miniBar; }
	public void setMiniBar(byte miniBar) { this.miniBar = miniBar; }
	public int getRoomId() { return this.roomId; }
	public void setRoomId(int roomId) { this.roomId = roomId; }
	public byte getRoomService() { return this.roomService; }
	public void setRoomService(byte roomService) { this.roomService = roomService; }
	public int getStartDate() { return this.startDate; }
	public void setStartDate(int startDate) { this.startDate = startDate; }
	public Customer getCustomer() { return this.customer; }
	public void setCustomer(Customer customer) { this.customer = customer; }
}
