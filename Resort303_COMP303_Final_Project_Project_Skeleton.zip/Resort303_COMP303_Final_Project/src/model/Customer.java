package model;
import java.io.Serializable;
import javax.persistence.*;
import java.util.List;
@Entity
@NamedQuery(name="Customer.findAll", query="SELECT c FROM Customer c")
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String email;
	private String fullname;
	private String passphrase;
	@OneToMany(mappedBy="customer")
	private List<Reservation> reservations;
	public Customer() { }
	public int getId() { return this.id; }
	public void setId(int id) { this.id = id; }
	public String getEmail() { return this.email; }
	public void setEmail(String email) { this.email = email; }
	public String getFullname() { return this.fullname; }
	public void setFullname(String fullname) { this.fullname = fullname; }
	public String getPassphrase() { return this.passphrase; }
	public void setPassphrase(String passphrase) { this.passphrase = passphrase; }
	public List<Reservation> getReservations() { return this.reservations; }
	public void setReservations(List<Reservation> reservations) { this.reservations = reservations; }
	public Reservation addReservation(Reservation reservation) {
		getReservations().add(reservation);
		reservation.setCustomer(this);
		return reservation;
	}
	public Reservation removeReservation(Reservation reservation) {
		getReservations().remove(reservation);
		reservation.setCustomer(null);
		return reservation;
	}
}
