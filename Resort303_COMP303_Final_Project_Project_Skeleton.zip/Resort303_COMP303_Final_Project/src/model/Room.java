package model;
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
@Entity
@NamedQuery(name="Room.findAll", query="SELECT r FROM Room r")
public class Room implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private BigDecimal price;
	private String roomdesc;
	private String roomimage;
	private String roomname;
	public Room() { }
	public int getId() { return this.id; }
	public void setId(int id) { this.id = id; }
	public BigDecimal getPrice() { return this.price; }
	public void setPrice(BigDecimal price) { this.price = price; }
	public String getRoomdesc() { return this.roomdesc; }
	public void setRoomdesc(String roomdesc) { this.roomdesc = roomdesc; }
	public String getRoomimage() { return this.roomimage; }
	public void setRoomimage(String roomimage) { this.roomimage = roomimage; }
	public String getRoomname() { return this.roomname; }
	public void setRoomname(String roomname) { this.roomname = roomname; }
}
